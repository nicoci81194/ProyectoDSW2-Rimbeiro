package pe.cib.rimbeiro.dto.Especialidad;

import lombok.Data;


@Data
public class EspecialidadDTO {

    private Long id;
    private String descripcion;
    private boolean estado;
}
